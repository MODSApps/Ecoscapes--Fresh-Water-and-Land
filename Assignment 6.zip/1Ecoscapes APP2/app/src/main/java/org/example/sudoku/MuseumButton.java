package org.example.sudoku;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by all on 7/21/2015.
 */
public class MuseumButton extends Activity
{
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.credits);

    }
}
