package org.example.sudoku;

import android.os.Bundle;

import org.example.sudoku.R;

/**
 * Created by all on 7/19/2015.
 */
public class CcHowToPlay extends CcGame
{
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cc_how_to_play);

    }
}
