package org.example.sudoku;

import android.os.Bundle;

/**
 * Created by all on 7/13/2015.
 */
public class Map extends Sudoku
{
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);
    }
}

