package org.example.sudoku;

import android.os.Bundle;

/**
 * Created by all on 7/19/2015.
 */
public class HowToPlay extends Display2
{
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help_me);

    }
}
