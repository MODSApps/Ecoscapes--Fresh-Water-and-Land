package org.example.sudoku;

import android.app.ActionBar;
import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by all on 7/13/2015.
 */
public class TurtleGame extends Activity
{
    private static final String TAG = "HelloService";
    View view;
    ImageView rabbitImg_1;
    ImageView rabbitImg_2;
    ImageView rabbitImg_3;
    ImageView rabbitImg_4;
    ImageView rabbitImg_5;
    ImageView rabbitImg_6;


    ImageView tortoise_1;
    ImageView tortoise_2;
    ImageView tortoise_3;
    ImageView tortoise_4;
    ImageView tortoise_5;
    ImageView tortoise_6;

    ArrayList<ImageView> turtles;
    ArrayList<ImageView> rabbits;

    ArrayList<Question> allQuestions;

    Button btn_true;
    Button btn_false;
    TextView tv_question;


    String answer;


    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.turtle_game);

        view = this.findViewById(android.R.id.content);

        rabbitImg_1 =(ImageView)view.findViewById(R.id.rabbit_1);
        rabbitImg_2 =(ImageView)view.findViewById(R.id.rabbit_2);
        rabbitImg_3 =(ImageView)view.findViewById(R.id.rabbit_3);
        rabbitImg_4 =(ImageView)view.findViewById(R.id.rabbit_4);
        rabbitImg_5 =(ImageView)view.findViewById(R.id.rabbit_5);
        rabbitImg_6 =(ImageView)view.findViewById(R.id.rabbit_6);

        rabbitImg_1.setVisibility(View.VISIBLE);
        rabbitImg_2.setVisibility(View.INVISIBLE);
        rabbitImg_3.setVisibility(View.INVISIBLE);
        rabbitImg_4.setVisibility(View.INVISIBLE);
        rabbitImg_5.setVisibility(View.INVISIBLE);
        rabbitImg_6.setVisibility(View.INVISIBLE);


       tortoise_1 =(ImageView)view.findViewById(R.id.tortoise_1);
        tortoise_2 =(ImageView)view.findViewById(R.id.tortoise_2);
        tortoise_3 =(ImageView)view.findViewById(R.id.tortoise_3);
        tortoise_4 =(ImageView)view.findViewById(R.id.tortoise_4);
        tortoise_5 =(ImageView)view.findViewById(R.id.tortoise_5);
       tortoise_6 =(ImageView)view.findViewById(R.id.tortoise_6);

        tortoise_1.setVisibility(View.VISIBLE);
        tortoise_2.setVisibility(View.INVISIBLE);
        tortoise_3.setVisibility(View.INVISIBLE);
        tortoise_4.setVisibility(View.INVISIBLE);
        tortoise_5.setVisibility(View.INVISIBLE);
        tortoise_6.setVisibility(View.INVISIBLE);

        rabbits=new ArrayList<ImageView>();
        turtles=new ArrayList<ImageView>();

        rabbits.add(rabbitImg_1);
        rabbits.add(rabbitImg_2);
        rabbits.add(rabbitImg_3);
        rabbits.add(rabbitImg_4);
        rabbits.add(rabbitImg_5);
        rabbits.add(rabbitImg_6);

        turtles.add(tortoise_1);
        turtles.add(tortoise_2);
        turtles.add(tortoise_3);
        turtles.add(tortoise_4);
        turtles.add(tortoise_5);
        turtles.add(tortoise_6);

         btn_true =(Button)view.findViewById(R.id.button);
        btn_false  =(Button)view.findViewById(R.id.button2);
         tv_question =(TextView)view.findViewById(R.id.textView22);

        allQuestions = new ArrayList<Question>();
        allQuestions.add(new Question("Rabbits are the same animals as hares.","false"));
        allQuestions.add(new Question("The Florida King Snake eats other snakes.","true"));
        allQuestions.add(new Question("The Three Toed Box Turtle has three toes on its two front legs.","false"));
        allQuestions.add(new Question("Gopher Tortoises are carnivores.","false"));
        allQuestions.add(new Question("The Florida Water Snake is non-venomous.","true"));
        allQuestions.add(new Question("The Eastern Indigo Snake is known to be the longest snake species in the US.","true"));
        allQuestions.add(new Question("Old World Rabbits thump their hind legs to warn against oncoming danger.","true"));





        nextQuestion();
    }

    public void nextQuestion(){
        Random rand = new Random();
        Question q = allQuestions.get(rand.nextInt(allQuestions.size() - 1));
        tv_question.setText(q.getQuestion());
        answer = q.getAnswer();
    }

    public void trueButtonPressed(View view){
        if (answer == "true"){
            showNextTurtle();
        }else{
            showNextRabbit();
        }
        nextQuestion();
    }

    public void falseButtonPressed(View view){
        if (answer == "false"){
            showNextTurtle();
        }else{
            showNextRabbit();
        }
        nextQuestion();
    }

    public void showNextRabbit()
    {
        for(int i=0;i<rabbits.size();i++)
        {
            if(rabbits.get(i).getVisibility() == View.VISIBLE)
            {
                rabbits.get(i).setVisibility(View.INVISIBLE);
                if(i != rabbits.size()-1)
                {
                    rabbits.get(i+1).setVisibility(View.VISIBLE);
                    return;
                }
            }
        }
    }
    public void showNextTurtle() {
        for (int i = 0; i < turtles.size(); i++) {
            if (turtles.get(i).getVisibility() == View.VISIBLE) {
                turtles.get(i).setVisibility(View.INVISIBLE);
                if (i != turtles.size() - 1) {
                    turtles.get(i + 1).setVisibility(View.VISIBLE);
                    return;
                }
            }
        }

    }

   // public void whoWon()
  //  {
  //  if (rabbits.View==Visible)
   // {
//then
  //  }
    //}

    public void resetRabbits()
    {
        for(int i=0;i<rabbits.size();i++)
        {
            rabbits.get(i).setVisibility(View.INVISIBLE);

        }
        rabbits.get(0).setVisibility(View.VISIBLE);
    }
    public void resetTurtles()
    {
        for(int i=0;i<turtles.size();i++)
        {
                turtles.get(i).setVisibility(View.INVISIBLE);

        }
        turtles.get(0).setVisibility(View.VISIBLE);
    }

}
