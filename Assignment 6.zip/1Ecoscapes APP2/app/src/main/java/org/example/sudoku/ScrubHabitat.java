package org.example.sudoku;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

/**
 * Created by all on 7/15/2015.
 */
public class ScrubHabitat extends Sudoku
{
    private static final String TAG = "Ecoscapes";
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scrub_habitat);

        View nextButton = findViewById(R.id.next_button);
        nextButton.setOnClickListener(this);
    }
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.next_button:
                Log.d(TAG, "clicked on " + "next_button");
                //launchApp();
           // Intent i = new Intent(this, ScrubInfo.class);
           //   startActivity(i);

              //Intent x = new Intent();
               //x.setAction("com.androidbegin.pagertabstriptutorial");
               // sendBroadcast(x);
                Intent intent = new Intent();
                intent.setAction("com.scrub.habitat");
                sendBroadcast(intent);

                break;
        }

    }
  //public void launchApp()
  //{

  //    Intent intent = new Intent();
  //    intent.setAction("com.scrub.habitat");
  //    sendBroadcast(intent);


  //}
}

