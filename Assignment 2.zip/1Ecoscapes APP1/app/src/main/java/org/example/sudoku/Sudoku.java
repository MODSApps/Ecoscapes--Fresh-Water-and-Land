/***
 * Excerpted from "Hello, Android",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material, 
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose. 
 * Visit http://www.pragmaticprogrammer.com/titles/eband3 for more book information.
***/
package org.example.sudoku;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Sudoku extends Activity implements OnClickListener
{
   MediaPlayer mySound;
    private static final String TAG = "Ecoscapes";

   /** Called when the activity is first created. */

   @Override
   public void onCreate(Bundle savedInstanceState)
   {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.main);
      //TODO
      View freshwaterButton = findViewById(R.id.freshwater_button);
      freshwaterButton.setOnClickListener(this);
      View upstairsButton = findViewById(R.id.upstairs_button);
      upstairsButton.setOnClickListener(this);
      View mapButton = findViewById(R.id.map_button);
      mapButton.setOnClickListener(this);
      View helpButton = findViewById(R.id.help_button);
      helpButton.setOnClickListener(this);

   }
    @Override
    protected void onResume() {
        super.onResume();
        org.example.sudoku.Music.play(this, R.raw.main);
    }

    @Override
    protected void onPause() {
        super.onPause();
        org.example.sudoku.Music.stop(this);
    }

    // ...
   public void onClick(View v)
   {
      switch (v.getId())
      {
         case R.id.freshwater_button:
            Log.d(TAG, "clicked on " + "freshwater_button");
            Intent i = new Intent(this, About.class);
            startActivity(i);
          break;
         case R.id.upstairs_button:
            Log.d(TAG, "clicked on " + "upstairs_button");
             Intent q=new Intent(this,UpstairsAnd.class);
             startActivity(q);
            break;
         case R.id.map_button:
            Log.d(TAG, "clicked on " + "map_button");
            break;
         case R.id.help_button:
            Log.d(TAG, "clicked on " + "help_button");
            break;
      }
   }
   
   @Override
   public boolean onCreateOptionsMenu(Menu menu)
   {
      super.onCreateOptionsMenu(menu);
      MenuInflater inflater = getMenuInflater();
      inflater.inflate(R.menu.menu, menu);
      return true;
   }

   @Override
   public boolean onOptionsItemSelected(MenuItem item)
   {
      switch (item.getItemId())
      {
      case R.id.settings:
         startActivity(new Intent(this, Prefs.class));
         return true;
      // More items go here (if any) ...
      }
      return false;
   }

   /** Ask the user what difficulty level they want */
   private void openNewGameDialog()
   {
      new AlertDialog.Builder(this)
           .setTitle(R.string.new_game_title)
           .setItems(R.array.difficulty,
            new DialogInterface.OnClickListener() {
               public void onClick(DialogInterface dialoginterface,
                     int i) {
                  startGame(i);
               }
            })
           .show();
   }
   
   /** Start a new game with the given difficulty level */
   private void startGame(int i)
   {
      Log.d(TAG, "clicked on " + i);
      // Start game here...
   }
}
