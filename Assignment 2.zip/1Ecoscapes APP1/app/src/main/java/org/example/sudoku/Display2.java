package org.example.sudoku;

import android.os.Bundle;
import android.view.View;

/**
 * Created by all on 7/12/2015.
 */
public class Display2 extends DisplayMessageActivity
{
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display2);

        View how_to_play_button = findViewById(R.id.how_to_play_button);
        how_to_play_button.setOnClickListener(this);
        View new_game_button = findViewById(R.id.new_game_button);
        new_game_button.setOnClickListener(this);
        View back_to_main_Button = findViewById(R.id.back_to_main_button);
        back_to_main_Button.setOnClickListener(this);
    }
}
