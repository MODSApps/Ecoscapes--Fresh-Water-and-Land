import android.app.Activity;
import android.os.Bundle;

import org.example.sudoku.R;

/**
 * Created by all on 7/12/2015.
 */
public class Freshwater1 extends Activity
{
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.freshwater1);
    }
}
