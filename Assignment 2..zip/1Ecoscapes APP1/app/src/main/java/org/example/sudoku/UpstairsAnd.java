package org.example.sudoku;

import android.os.Bundle;

/**
 * Created by all on 7/12/2015.
 */
public class UpstairsAnd extends Sudoku
{
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.and_upstairs);
    }
}