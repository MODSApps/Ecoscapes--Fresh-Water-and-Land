/***
 * Excerpted from "Hello, Android",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/eband3 for more book information.
 ***/
package org.example.sudoku;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class About extends Sudoku implements View.OnClickListener
{
    private static final String TAG = "Ecoscapes";
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);

        View continueButton = findViewById(R.id.continue_button);
        continueButton.setOnClickListener(this);
        View back_to_main_Button = findViewById(R.id.back_to_main_button);
        back_to_main_Button.setOnClickListener(this);
    }
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.continue_button:
                Log.d(TAG, "clicked on " + "continue_button");
                Intent i = new Intent(this, DisplayMessageActivity.class);
                startActivity(i);
                break;
            case R.id.back_to_main_button:
                Log.d(TAG, "clicked on " + "back_to_main_button");
                Intent j = new Intent(this,Sudoku.class);
                startActivity(j);
                break;
        }
    }

}



