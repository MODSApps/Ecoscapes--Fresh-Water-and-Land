package com.triviagame;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

//This activity is called after displaying 10 questions
public class finalscore extends Activity implements OnClickListener
{

	int finalScoreValue = 0;
	int categoryIdInFinalActivity = 0;
	String finalScoreValueString;

	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.finalscore);

		finalScoreValue = com.triviagame.Trivia_Game.finalScore;
		categoryIdInFinalActivity = com.triviagame.Trivia_Game.categoryIdInMainMenu;

		//Displays final score
		TextView finalScore = (TextView) findViewById(R.id.finalscore);
		finalScoreValueString = Integer.toString(finalScoreValue);
		finalScore.setText(finalScoreValueString);


		TextView finalScoreImage = (TextView) findViewById(R.id.finalscore);

		//Display and listener for New Game button
		View newGameButton =  findViewById (R.id.buttonnewgame);
		newGameButton.setOnClickListener(this);

		//Sets final image and message according to the category and the final score
		switch (categoryIdInFinalActivity){
			//geography
			case 0:
				if (finalScoreValue  <= 60){
					TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
					finalMessageLabel.setText("Try reading the information in the exhibit and on the app again.");
					finalScoreImage.setBackgroundResource(R.drawable.joeythumbsup);
				}
				else
				if (finalScoreValue > 60 ){
					TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
					finalMessageLabel.setText("Good job, you are an animal expert!");
					finalScoreImage.setBackgroundResource(R.drawable.joeythumbsup);

				}
				break;

			//politics
			case 1:
				if (finalScoreValue  <= 60){
					TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
					finalMessageLabel.setText("Go back to read more information!");
					finalScoreImage.setBackgroundResource(R.drawable.joeythumbsup);
				}
				else
				if (finalScoreValue > 60 ){
					TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
					finalMessageLabel.setText("Good job,Joey gives you thumbs up!");
					finalScoreImage.setBackgroundResource(R.drawable.joeythumbsup);

				}
				break;

			//history
			case 2:    if (finalScoreValue  <= 60){
				TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
				finalMessageLabel.setText("Try again!");
				finalScoreImage.setBackgroundResource(R.drawable.joeythumbsup);
			}
			else
			if (finalScoreValue > 60 ){
				TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
				finalMessageLabel.setText("Good job, Joey would be proud of you!");
				finalScoreImage.setBackgroundResource(R.drawable.joeythumbsup);

			}
				break;

			//sports
			case 3:    if (finalScoreValue  <= 60){
				TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
				finalMessageLabel.setText("Try again next time!");
				finalScoreImage.setBackgroundResource(R.drawable.joeythumbsup);
			}
			else
			if (finalScoreValue > 60 ){
				TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
				finalMessageLabel.setText("Good job, Joey would be proud of you!");
				finalScoreImage.setBackgroundResource(R.drawable.joeythumbsup);

			}
				break;

			//science
			case 4:    if (finalScoreValue  <= 60){
				TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
				finalMessageLabel.setText("Try again next time!");
				finalScoreImage.setBackgroundResource(R.drawable.joeythumbsup);
			}
			else
			if (finalScoreValue > 60 ){
				TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
				finalMessageLabel.setText("Good job, You are an animal expert!");
				finalScoreImage.setBackgroundResource(R.drawable.joeythumbsup);

			}
				break;

			//movies
			case 5:    if (finalScoreValue  <= 60){
				TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
				finalMessageLabel.setText("You should read the information again");
				finalScoreImage.setBackgroundResource(R.drawable.joeythumbsup);
			}
			else
			if (finalScoreValue > 60 ){
				TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
				finalMessageLabel.setText("Good job, Joey the otter would be proud of you!");
				finalScoreImage.setBackgroundResource(R.drawable.joeythumbsup);

			}
				break;

			//general
			case 6:    if (finalScoreValue  <= 50){
				TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
				finalMessageLabel.setText("Nice try! There is a lot to learn, so go and explore the museum!");

			}
			else
			if (finalScoreValue > 50 ){
				TextView finalMessageLabel = (TextView) findViewById(R.id.finalmessage);
				finalMessageLabel.setText("Good job! You're an Oak Forest animal expert!");


			}
				break;

		}
	}


	//Listeners for button(s)
	@Override
	public void onClick(View v) {

		switch (v.getId()) {

			case R.id.buttonnewgame:
				Intent g = new Intent(this,Trivia_Game.class);
				startActivity(g);

		}
	}


	@Override
	protected void onResume(){
		super.onResume();
		music.play(this, R.raw.musicbackground);   //start playing background music
	}

	@Override
	protected void onPause(){
		super.onPause();
		music.stop(this);     //stop playing background music
	}

}