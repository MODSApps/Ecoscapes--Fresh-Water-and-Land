package com.freshwater.friends;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.freshwater.friends.FragmentTab1;
import com.freshwater.friends.FragmentTab2;
import com.freshwater.friends.FragmentTab3;

public class ViewPagerAdapter extends FragmentPagerAdapter {

	final int PAGE_COUNT = 8;
	// Tab Titles
	private String tabtitles[] = new String[] { "Desert Blond Tarantula", "Asian Forest Scorpion", "Day Gecko","Curly Hair Tarantula","Egyptian Fruit Bat","Flat Rock Scorpion","Emperor Scorpion","Desert Millipede"};
	Context context;

	public ViewPagerAdapter(FragmentManager fm) {
		super(fm);
	}

	@Override
	public int getCount()
    {
		return PAGE_COUNT;
	}

	@Override
	public Fragment getItem(int position)
    {
		switch (position) {

			// Open FragmentTab1.java
		case 0:
			FragmentTab1 fragmenttab1 = new FragmentTab1();
			return fragmenttab1;

			// Open FragmentTab2.java
		case 1:
			FragmentTab2 fragmenttab2 = new FragmentTab2();
			return fragmenttab2;

			// Open FragmentTab3.java
		case 2:
			FragmentTab3 fragmenttab3 = new FragmentTab3();
			return fragmenttab3;

			case 3:
				FragmentTab4 frag4 = new FragmentTab4();
				return frag4;
            case 4:
                FragmentTab5 frag5 = new FragmentTab5();
                return frag5;
            case 5:
                FragmentTab6 frag6 = new FragmentTab6();
                return frag6;
            case 6:
                FragmentTab7 frag7 = new FragmentTab7();
                return frag7;
            case 7:
                FragmentTab8 frag8 = new FragmentTab8();
                return frag8;
		}
		return null;
	}

	@Override
	public CharSequence getPageTitle(int position)
    {
		return tabtitles[position];
	}
}
