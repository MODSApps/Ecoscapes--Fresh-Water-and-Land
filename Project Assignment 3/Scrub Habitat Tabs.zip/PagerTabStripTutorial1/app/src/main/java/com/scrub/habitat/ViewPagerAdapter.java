package com.scrub.habitat;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class ViewPagerAdapter extends FragmentPagerAdapter {

	final int PAGE_COUNT = 8;
	// Tab Titles
	private String tabtitles[] = new String[] { "Old-World Rabbit", "Corn Snake", "Gopher Tortoise","Eastern Indigo Snake","Eastern Box Turtle","Florida Box Turtle","Florida King Snake","Florida Water Snake" };
	Context context;

	public ViewPagerAdapter(FragmentManager fm) {
		super(fm);
	}

	@Override
	public int getCount() {
		return PAGE_COUNT;
	}

	@Override
	public Fragment getItem(int position) {
		switch (position) {

			// Open FragmentTab1.java
		case 0:
			FragmentTab1 fragmenttab1 = new FragmentTab1();
			return fragmenttab1;

			// Open FragmentTab2.java
		case 1:
			FragmentTab2 fragmenttab2 = new FragmentTab2();
			return fragmenttab2;

			// Open FragmentTab3.java
		case 2:
			FragmentTab3 fragmenttab3 = new FragmentTab3();
			return fragmenttab3;
			case 3:
				Frag4 frag4=new Frag4();
				return frag4;
			case 4:
				Frag5 frag5 = new Frag5();
				return frag5;
			case 5:
				Frag6 frag6 = new Frag6();
				return frag6;
			case 6:
				Frag7 frag7 = new Frag7();
				return frag7;
			case 7:
				Frag8 frag8 = new Frag8();
				return frag8;
		}
		return null;
	}

	@Override
	public CharSequence getPageTitle(int position) {
		return tabtitles[position];
	}
}
