package org.example.sudoku;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

/**
 * Created by all on 7/15/2015.
 */
public class ScrubGame extends ScrubInfo
{
    private static final String TAG = "Ecoscapes";

    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scrub_game);

        View how_to_play_Button = findViewById(R.id.how_to_play_button);
        how_to_play_Button.setOnClickListener(this);
        View new_game_Button = findViewById(R.id.new_game_button);
        new_game_Button.setOnClickListener(this);
    }
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.how_to_play_button:
                Log.d(TAG, "clicked on " + "how_to_play_button");
                Intent i = new Intent(this, ScrubHowTo.class);
                startActivity(i);
                break;
            case R.id.new_game_button:
                Log.d(TAG, "clicked on " + "new_game_button");
                Intent m = new Intent(this,TurtleGame.class);
                startActivity(m);
                break;
        }
    }

}



