package org.example.sudoku;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

/**
 * Created by all on 7/12/2015.
 */
public class Display2 extends DisplayMessageActivity

{
private static final String TAG = "Ecoscapes";
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display2);

        View how_to_play_button = findViewById(R.id.how_to_play_button);
        how_to_play_button.setOnClickListener(this);
        View new_game_button = findViewById(R.id.new_game_button);
        new_game_button.setOnClickListener(this);
        View back_to_main_Button = findViewById(R.id.back_to_main_button);
        back_to_main_Button.setOnClickListener(this);

    }

    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.how_to_play_button:
                Log.d(TAG, "clicked on " + "how_to_play_button");
                Intent f = new Intent(this, HowToPlay.class);
                startActivity(f);

                break;
            case R.id.new_game_button:
                Log.d(TAG, "clicked on " + "game_button");
                //Intent k= new Intent(this,Display2.class);
                //startActivity(k);
                break;
            case R.id.back_to_main_button:
                Log.d(TAG, "clicked on " + "back_to_main_button");
                Intent a = new Intent(this, Sudoku.class);
                startActivity(a);
                break;
        }
    }

}

