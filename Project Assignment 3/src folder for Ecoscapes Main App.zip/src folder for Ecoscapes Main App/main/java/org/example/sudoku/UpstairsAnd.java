package org.example.sudoku;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class UpstairsAnd extends Sudoku
{
    private static final String TAG = "Ecoscapes";

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.and_upstairs);

        View nextButton = findViewById(R.id.next_button);
        nextButton.setOnClickListener(this);

    }
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.next_button:
                Log.d(TAG, "clicked on " + "next_button");
               // Intent i = new Intent(this, CreepyCrawlerInfo.class);
               // startActivity(i);
               //Intent intent = new Intent();
               //intent.setAction("com.scrub.habitat");
               //sendBroadcast(intent);
                launchApp();

                break;

        }
    }
    public void launchApp()
{

    Intent intent = new Intent();
    intent.setAction("com.freshwater.friends");
    sendBroadcast(intent);


}

}
