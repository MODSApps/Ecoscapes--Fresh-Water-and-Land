package org.example.sudoku;

import android.os.Bundle;

/**
 * Created by all on 7/19/2015.
 */
public class ScrubHowTo extends ScrubGame
{
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scrub_how_to);

    }
}
