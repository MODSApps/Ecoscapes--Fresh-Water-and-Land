package org.example.sudoku;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by all on 7/23/2015.
 */
public class MyBroadcastReceiver extends BroadcastReceiver
{

    @Override
    public void onReceive(Context context, Intent intent)
    {


        if (intent.getAction().equals("org.example.sudoku"))
        {
            Intent i = new Intent(context, ScrubGame.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
        }
    }

}
