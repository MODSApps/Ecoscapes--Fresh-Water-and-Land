/***
 * Excerpted from "Hello, Android",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/eband3 for more book information.
 ***/
package org.example.sudoku;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import org.example.sudoku.R;

public class About extends Sudoku
{
    private static final String TAG = "Ecoscapes";
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);

        View nextButton = findViewById(R.id.next_button);
        nextButton.setOnClickListener(this);

    }
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.next_button:
                Log.d(TAG, "clicked on " + "next_button - 1");
                //Intent i = new Intent(this, DisplayMessageActivity.class);
                //startActivity(i);
             //  Intent LaunchIntent = getPackageManager()
             //      .getLaunchIntentForPackage("com.androidbegin.pagertabstriptutorial");
             // startActivity(LaunchIntent);

                Intent intent = new Intent();
                intent.setAction("com.androidbegin.pagertabstriptutorial");
                sendBroadcast(intent);

                //launchApp();
                break;
        }
    }
   // public void launchApp()
 // {

 //     Intent intent = new Intent();
 //     intent.setAction("com.freshwater.friends");
 //     sendBroadcast(intent);


 // }

}



