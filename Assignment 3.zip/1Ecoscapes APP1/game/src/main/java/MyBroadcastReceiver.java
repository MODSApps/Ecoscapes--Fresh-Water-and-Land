import android.content.Context;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.triviagame.Trivia_Game;

/**
 * Created by all on 7/17/2015.
 */


    public class MyBroadcastReceiver extends BroadcastReceiver
    {
        public MyBroadcastReceiver() {
        }

        @Override
        public void onReceive(Context context, Intent intent)
        {


            if (intent.getAction().equals("com.triviagame"))
            {
                Intent i = new Intent(context, Trivia_Game.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        }

    }

