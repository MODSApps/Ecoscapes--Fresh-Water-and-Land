package drawable

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;


public class DisplayMessageActivity extends About
{
    private static final String TAG = "Ecoscapes";
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);

        View nextButton = findViewById(R.id.next_button);
        nextButton.setOnClickListener(this);
        View gameButton = findViewById(R.id.game_button);
        gameButton.setOnClickListener(this);
        View back_to_main_Button = findViewById(R.id.back_to_main_button);
        back_to_main_Button.setOnClickListener(this);

    }
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.next_button:
                Log.d(TAG, "clicked on " + "next_button");
                Intent f = new Intent(this, Display2.class);
                startActivity(f);
                break;
            case R.id.game_button:
                Log.d(TAG, "clicked on " + "game_button");
                Intent k= new Intent(this,Display2.class);
                startActivity(k);
                break;
            case R.id.back_to_main_button:
                Log.d(TAG, "clicked on " + "back_to_main_button");
                Intent a = new Intent(this, Sudoku.class);
                startActivity(a);
                break;
        }
    }

}


