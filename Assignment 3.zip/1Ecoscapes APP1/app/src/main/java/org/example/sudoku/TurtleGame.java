package org.example.sudoku;

import android.os.Bundle;

/**
 * Created by all on 7/13/2015.
 */
public class TurtleGame extends UpstairsAnd
{
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.turtle_game);

    }

}
