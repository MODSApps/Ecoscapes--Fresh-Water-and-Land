package org.example.sudoku;

import android.app.Activity;
import android.os.Bundle;


/**
 * Created by all on 7/13/2015.
 */
public class HelpMe extends Activity
{
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help_me);

    }
}
