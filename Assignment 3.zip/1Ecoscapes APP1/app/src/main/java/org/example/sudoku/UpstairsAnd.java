package org.example.sudoku;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class UpstairsAnd extends Sudoku
{
    private static final String TAG = "Ecoscapes";

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.and_upstairs);

        View continueButton = findViewById(R.id.continue_button);
        continueButton.setOnClickListener(this);
        View back_to_main_Button = findViewById(R.id.back_to_main_button);
        back_to_main_Button.setOnClickListener(this);
    }
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.continue_button:
                Log.d(TAG, "clicked on " + "continue_button");
                Intent i = new Intent(this, CreepyCrawlerInfo.class);
                startActivity(i);
                break;
            case R.id.back_to_main_button:
                Log.d(TAG, "clicked on " + "back_to_main_button");
                Intent j = new Intent(this,Sudoku.class);
                startActivity(j);
                break;
        }
    }

}
