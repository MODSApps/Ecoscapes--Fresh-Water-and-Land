package org.example.sudoku;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

/**
 * Created by all on 7/15/2015.
 */
public class ScrubInfo extends ScrubHabitat
{
    private static final String TAG = "Ecoscapes";
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scrub_info);

        View gameButton = findViewById(R.id.game_button);
        gameButton.setOnClickListener(this);
        View back_to_main_Button = findViewById(R.id.back_to_main_button);
        back_to_main_Button.setOnClickListener(this);
    }
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.game_button:
                Log.d(TAG, "clicked on " + "game_button");
                Intent m = new Intent(this,ScrubGame.class);
                startActivity(m);
                break;

            case R.id.back_to_main_button:
                Log.d(TAG, "clicked on " + "back_to_main_button");
                Intent j = new Intent(this,Sudoku.class);
                startActivity(j);
                break;
        }
    }

}
