package org.example.sudoku;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import org.example.sudoku.R;

/**
 * Created by all on 7/15/2015.
 */
public class CreepyCrawlerInfo extends Sudoku
{
    private static final String TAG = "Ecoscapes";
        @Override
        public void onCreate(Bundle savedInstanceState)
        {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.creepy_crawler_info);

            View gameButton = findViewById(R.id.game_button);
            gameButton.setOnClickListener(this);
            View back_to_main_Button = findViewById(R.id.back_to_main_button);
            back_to_main_Button.setOnClickListener(this);
        }
        public void onClick(View v)
        {
            switch (v.getId())
            {
                   // Intent LaunchIntent = getPackageManager()
                   //         .getLaunchIntentForPackage("fau.edu.gallerytest");
                //startActivity(LaunchIntent);

                case R.id.game_button:
                    Log.d(TAG, "clicked on " + "game_button");
                    Intent m = new Intent(this,CcGame.class);
                    startActivity(m);
                    break;

                case R.id.back_to_main_button:
                    Log.d(TAG, "clicked on " + "back_to_main_button");
                    Intent j = new Intent(this,Sudoku.class);
                    startActivity(j);
                    break;
            }
        }

    }

